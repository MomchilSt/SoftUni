﻿namespace TheTankGame.Tests
{
    using NUnit.Framework;
    using System;
    //using TheTankGame.Entities.Parts.Factories;
    //using TheTankGame.Entities.Vehicles.Factories;

    //using TheTankGame.Entities.Miscellaneous;
    //using TheTankGame.Entities.Parts;
    //using TheTankGame.Entities.Vehicles;

    [TestFixture]
    public class BaseVehicleTests
    {
        [Test]
        public void TestVehiclesVanguard()
        {
            var vehicle = new Vanguard("Sporten", 14, 4000, 200, 3000, 3001, new VehicleAssembler());

            string model = vehicle.Model;
            var getVehicleAttackVehicle = vehicle.Attack;
            var getWeight = vehicle.Weight;
            var getPrice = vehicle.Price;
            var getDefence = vehicle.Defense;
            var getHitPoints = vehicle.HitPoints;

            Assert.That(model, Is.EqualTo("Sporten"));
            Assert.That(getVehicleAttackVehicle, Is.EqualTo(vehicle.Attack));
            Assert.That(getWeight, Is.EqualTo(vehicle.Weight));
            Assert.That(getPrice, Is.EqualTo(vehicle.Price));
            Assert.That(getDefence, Is.EqualTo(vehicle.Defense));
            Assert.That(getHitPoints, Is.EqualTo(vehicle.HitPoints));
        }

        [Test]
        public void TestVehicleProperties()
        {
            var vanguard = new Vanguard("Sporten", 14, 4000, 200, 3000, 3001, new VehicleAssembler());

            var expectedWeight = vanguard.TotalWeight;
            var expectedPrice = vanguard.TotalPrice;
            var expectedHitPoints = vanguard.TotalHitPoints;
            var expectedDefence = vanguard.TotalDefense;
            var expectedAttack = vanguard.TotalAttack;

            Assert.That(expectedWeight, Is.EqualTo(vanguard.TotalWeight));
            Assert.That(expectedPrice, Is.EqualTo(vanguard.TotalPrice));
            Assert.That(expectedHitPoints, Is.EqualTo(vanguard.TotalHitPoints));
            Assert.That(expectedDefence, Is.EqualTo(vanguard.TotalDefense));
            Assert.That(expectedAttack, Is.EqualTo(vanguard.TotalAttack));
        }

        [Test]
        public void TestVehicleFieldsLowering()
        {


            Assert.That(() => new Revenger("Sporten", 14, 4000, 200, 3000, -1, new VehicleAssembler()), Throws.ArgumentException.With
                .Message.EqualTo("HitPoints cannot be less than zero!"));
        }

        [Test]
        public void TestToString()
        {

            var vanguard = new Vanguard("Sporten", 14, 4000, 200, 3000, 3001, new VehicleAssembler());

            var expectedResult = "Vanguard - Sporten\r\nTotal Weight: 14.000\r\nTotal Price: 4000.000\r\nAttack: 200\r\nDefense: 3000\r\nHitPoints: 3001\r\nParts: None";

            var actual = vanguard.ToString();

            Assert.That(actual, Is.EqualTo(expectedResult));
        }

        [Test]
        public void TestToStringWithParts()
        {

            var vanguard = new Vanguard("Sporten", 14, 4000, 200, 3000, 3001, new VehicleAssembler());
            vanguard.AddArsenalPart(new ArsenalPart("asd", 213, 33, 31));

            var expectedResult = "Vanguard - Sporten\r\nTotal Weight: 227.000\r\nTotal Price: 4033.000\r\nAttack: 231\r\nDefense: 3000\r\nHitPoints: 3001\r\nParts: asd";

            var actual = vanguard.ToString();

            Assert.That(actual, Is.EqualTo(expectedResult));
        }

    }
}